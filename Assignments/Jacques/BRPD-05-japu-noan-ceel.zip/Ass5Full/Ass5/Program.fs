﻿


//5.1 A

let merge (xs: int list) (ys: int list) =
    [xs; ys] |> List.concat |> List.sort