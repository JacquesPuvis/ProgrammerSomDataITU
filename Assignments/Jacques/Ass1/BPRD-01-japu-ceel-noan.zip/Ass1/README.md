READ THIS AMAZING README

1.1, 1.2. can be found in Ass1fsharp/assignment1part1.fs
1.4 canf be found in /Ass1csharp
2.1, 2.2, 2.3 can be found in Ass1fsarhp/assignment1part2.fs