void main() {
    int a;
    a = 5;
    ++a;
    print a;
    --a;
    print a;
}