// micro-C example 

void main() { 
  int i; 
  i=1; 
  print (i ? 1 : 0);
}
